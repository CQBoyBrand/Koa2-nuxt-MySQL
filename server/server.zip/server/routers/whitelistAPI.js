/**
 * Author：brand
 * Creation Time：2019-03-15 16:02
 * Email：brandhuang@qq.com
 */

const whitelistAPI = [
/login/,
/register/,
/getArticleListAll/,
/getArticleDetail/,
/getArticleHot/,
/getFontTagList/,
/getFontCategoryList/,
/getArticleListByTag/,
/getArtByCategory/,
/getArtByTitle/,
/getArchive/,
/addComment/,
/getComment/,
/addReplyComment/,
]
module.exports =  whitelistAPI