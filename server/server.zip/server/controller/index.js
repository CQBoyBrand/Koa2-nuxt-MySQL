/**
 * Author：brand
 * Creation Time：2019-03-10 18:56
 * Email：brandhuang@qq.com
 */

exports.tag = require('./tag.controller')
exports.category = require('./category.controller')
exports.auth = require('./auth.controller')
exports.qiniu = require('./qiniu.controller')
exports.article = require('./article.controller')
exports.comments = require('./comments.controller')
exports.link = require('./link.controller')
exports.archive = require('./archive.controller')