/**
 * Author：Brand
 * Email：brandhuang@qq.com
 * CreateTime: 2020/2/21 00:04
 * Description:
 */
export interface LinkInterface {

}