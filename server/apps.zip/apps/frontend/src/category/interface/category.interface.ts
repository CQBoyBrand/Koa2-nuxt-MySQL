/**
 * Author：Brand
 * Email：brandhuang@qq.com
 * CreateTime: 2020/2/19 11:29
 * Description:
 */

export interface CategoryInterface {
    
}