/**
 * Author：Brand
 * Email：brandhuang@qq.com
 * CreateTime: 2020/2/12 17:10
 * Description:
 */

export interface CategoryInterface {
    id: number;
    categoryname: string;
    categorydesc: string,
    cdate: number;

}