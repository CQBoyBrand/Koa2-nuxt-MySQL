/**
 * Author：Brand
 * Email：brandhuang@qq.com
 * CreateTime: 2020/2/12 17:10
 * Description:
 */

export interface TagInterface {
    id: number;
    tagname: string;
    tagdesc: string,
    status: number;
    cdate: number;

}